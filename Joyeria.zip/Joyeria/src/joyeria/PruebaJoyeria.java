
package joyeria;
import java.util.Arrays;
public class PruebaJoyeria{
    //Clase Prueba/Ejecutor.
    public static void main(String[] args) {
        //Inicializacion de los valores del Arreglo.
        double precio[] = {100.50, 45.70, 756.0, 56.12};
        //Creacion del objeto de tipo Joyeria
        Joyeria joyas = new Joyeria("Collares", precio);
        joyas.calcularPromedioVent();
        System.out.print(joyas);
    }
}
class Joyeria {
    //Declaracion de datos o atributos de la clase.
    public String categoria;
    public double[] precio;
    public double promedioVent;
    //Constructor
    public Joyeria(String categoria, double[] precio) {
        this.categoria = categoria;
        this.precio = precio;
    }
    //Metodo toString para devolver una cadena con los valores dados a los atributos de la instancia.
    @Override
    public String toString() {
        return """
               Joyeria{
               Categoria: """ + categoria + "\n" 
                + "Precio: " + Arrays.toString(precio) + "\n" 
                + "PromedioVent=" + promedioVent + "\n" +'}';
    }
    //Metodo para calcular el promedio de venta de los productos pertenecientes a la categoria.
    public void calcularPromedioVent(){
        double suma = 0;
        for (double precios : precio){
            suma += precios;
        }
        this.promedioVent = suma/precio.length;
    }  
}